// SPDX-License-Identifier: GPL-3.0-or-later
// background.js - service worker.
// Owns ONE resilient WebSocket to the local bridge (ws://127.0.0.1:PORT).
// Keeping the socket here (not in the content script) avoids https→ws mixed
// content issues and centralises reconnect / timeout logic.
//
// Contract with content.js: every sendMessage ALWAYS gets a response object,
// even when the bridge is offline. The agentic loop must never hang waiting.

const PAIRING_KEY = "plazcode-pairing-key";
let fullSyncedOnce = false;
let pairingKey = "";
let pairingInFlight = null;
const pairingReady = chrome.storage.local.get(PAIRING_KEY).then((value) => {
  pairingKey = value[PAIRING_KEY] || "";
}).catch(() => {});
async function ensurePairing(force = false) {
  await pairingReady;
  if (pairingInFlight) return pairingInFlight;
  if (!force && /^[a-f0-9]{64}$/i.test(pairingKey)) return pairingKey;
  pairingInFlight = (async () => {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 5000);
    try {
      const response = await fetch("http://127.0.0.1:3000/api/pair", {
        method: "POST", mode: "cors", credentials: "omit", redirect: "error",
        headers: { "Content-Type": "application/json", "X-PlazCode-Extension": chrome.runtime.id },
        body: "{}", signal: controller.signal,
      });
      if (!response.ok) throw new Error("Automatic pairing failed; use the matching 1.18.53 agent and extension.");
      const data = await response.json();
      if (!/^[a-f0-9]{64}$/i.test(data.key || "")) throw new Error("Agent returned an invalid pairing response");
      pairingKey = data.key;
      try { await chrome.storage.local.set({ [PAIRING_KEY]: pairingKey }); } catch {}
      return pairingKey;
    } finally { clearTimeout(timer); }
  })();
  try { return await pairingInFlight; } finally { pairingInFlight = null; }
}
function pairingProtocols() {
  if (!/^[a-f0-9]{64}$/i.test(pairingKey)) throw new Error("Agent pairing is not ready");
  return ["plazcode", "plazcode-auth." + pairingKey];
}
async function bridgeFetch(url, options = {}) {
  await ensurePairing();
  for (let attempt = 0; attempt < 2; attempt++) {
    const headers = new Headers(options.headers || {});
    headers.set("Authorization", "Bearer " + pairingKey);
    const response = await fetch(url, { ...options, headers, redirect: "error" });
    if (response.status !== 401) return response;
    if (attempt === 0) await ensurePairing(true);
  }
  throw new Error("Agent authentication failed after automatic pairing");
}

const PORT_ROBLOX = 17613;
const PORT_LOCAL = 17615; // AgentScript — native FS/terminal engine
const BLENDER_ADDON_PORT = 9876;
const RUST_ROBLOX_HTTP = "http://127.0.0.1:3000";
const ENGINE_KEY = "rs-engine";
// "anim" (Animation mode) is a persona-driven view of the SAME Roblox bridge:
// it maps to 17613 everywhere a port/HTTP target is picked, but keeps its own
// id so prompts, accents and UI state stay engine-isolated.
const ENGINES = ["roblox", "local"];
function normalizeEngine(v) { return v === "local" ? "local" : "roblox"; }
let engine = "roblox"; // "roblox" | "local"
let rustMode = false; // true if Rust agent on 3000 is reachable (preferred)
chrome.storage?.local.get(ENGINE_KEY, (o) => {
  const want = normalizeEngine(o && o[ENGINE_KEY]);
  if (want !== engine) {
    engine = want;
    log(`engine init corrected to ${engineLabel()} -> ${engineUrl()}`);
    try { ws?.close(); } catch {}
    connected = false;
    reconnectDelay = RECONNECT_MIN;
    connect();
    broadcastStatus();
  }
});
// Probe Rust agent on 3000 at startup — if reachable, use HTTP pipe (CORS bypass) as primary
(async () => {
  try {
    const r = await bridgeFetch(`${RUST_ROBLOX_HTTP}/api/status`, { method: "GET" });
    if (r.ok) {
      rustMode = true;
      log("Rust agent detected on 3000 — HTTP pipe enabled (CORS bypass via background)");
    }
  } catch {}
})();
function engineUrl() { return `ws://127.0.0.1:${engine === "local" ? PORT_LOCAL : PORT_ROBLOX}`; }
function engineHttpUrl() { return RUST_ROBLOX_HTTP; }
function engineLabel() { return engine === "local" ? "AgentScript" : "Roblox"; }
chrome.storage?.onChanged.addListener((changes, area) => {
  if (area === "local" && changes[ENGINE_KEY]) {
    const want = normalizeEngine(changes[ENGINE_KEY].newValue);
    if (want === engine) return; // dedupe rs-set-engine double fire
    engine = want;
    log(`engine switched to ${engineLabel()} -> ${engineUrl()} — FULL ISOLATION`);
    try { ws?.close(); } catch {}
    connected = false;
    mcpAlive = false;
    toolsCache = [];
    serversCache = [];
    studioConnected = null;
    studioApp = null;
    studioProc = null;
    failAllPending(`engine switched to ${engine}`);
    reconnectDelay = RECONNECT_MIN;
    connect();
    broadcastStatus();
  }
});

// Chat sites where an PlazCode provider content script runs. Status pushes go
// to every tab matching these. Add the new provider's URL pattern here (and in
// manifest.json content_scripts + host_permissions) when integrating another AI.
const PROVIDER_URLS = ["https://chat.deepseek.com/*", "https://deepseek.com/*", "https://chatgpt.com/*", "https://chat.openai.com/*", "https://claude.ai/*", "https://www.claude.ai/*", "https://claude.com/*", "https://www.claude.com/*", "https://gemini.google.com/*", "https://www.kimi.com/*", "https://kimi.com/*", "https://kimi.ai/*", "https://www.kimi.ai/*", "https://chat.z.ai/*", "https://chat.qwen.ai/*", "https://arena.ai/*", "https://www.notion.so/*", "https://app.notion.so/*", "https://www.notion.com/*", "https://notion.com/*", "https://*.notion.com/*", "https://freebuff.ai/*", "https://www.freebuff.ai/*", "https://freebuff.com/*", "https://www.freebuff.com/*", "https://www.meta.ai/*", "https://meta.ai/*", "https://github.com/copilot", "https://github.com/copilot/*", "https://copilot.microsoft.com/*", "https://m365.cloud.microsoft/*", "https://gpt.crax.lol/*", "https://use.ai/*", "https://www.use.ai/*", "https://oxalpha.com/*", "https://www.oxalpha.com/*", "https://oxalpha.org/*", "https://www.oxalpha.org/*", "http://localhost/*", "http://127.0.0.1/*", "https://ollama.com/*", "https://*.ollama.com/*"];

const RECONNECT_MIN = 500;
const RECONNECT_MAX = 5000;
const HEARTBEAT_MS = 10000;
// If no message (incl. pong) arrives within this window while we believe we're
// connected, the socket is half-open: force a reconnect instead of letting
// pending requests slowly time out.
const STALE_SOCKET_MS = 140000; // above 120s tool timeout so a long execute_luau never looks half-open
const REQUEST_TIMEOUT_DEFAULT = 130000; // a bit above the 120s tool timeout

let ws = null;
let connected = false;
let reconnectDelay = RECONNECT_MIN;
let reconnectTimer = null;
let heartbeatTimer = null;
let lastMessageAt = 0; // timestamp of the last frame received from the bridge
let nextId = 1;
const pending = new Map(); // id -> {resolve, timer}
let toolsCache = [];
let mcpAlive = false;
let serversCache = [];
// true/false = a PLACE is loaded and usable in Roblox Studio; null = unknown.
// The MCP process stays alive when Studio is closed or its MCP option is off,
// so this is probed separately (bridge "studio_status").
let studioConnected = null;
// true/false = a Roblox Studio app is connected to the MCP server at all; null =
// unknown. studioApp=true with studioConnected=false means "Studio open but no
// place"; studioApp=false means "Studio closed PlazCode its MCP option disabled".
let studioApp = null;
// true/false = a Roblox Studio WINDOW/PROCESS exists on this machine (checked
// bridge-side via tasklist); null = unknown/old bridge. Distinguishes the two
// studioApp=false sub-cases the UI must word differently: Studio genuinely not
// launched ("open Roblox Studio") vs Studio OPEN but its MCP plugin never
// registered with the bridge - the documented fix for the latter is opening
// Assistant Settings > MCP Servers inside Studio (validated live 3x), which
// "open Roblox Studio" wording completely fails to convey.
let studioProc = null;
let robloxProc = false;
// Editor-backed status. A local bridge socket is not an editor connection.
let robloxEditorConnected = false;
let localReady = false; // agent's workspace is up (from /api/status local_ready)
let localFull = false; // AgentScript FULL PC ACCESS (agent is source of truth)
let localRoot = ""; // workspace path, injected into the AI's state line
let blenderAddon = false; // blender-mcp addon listening on TCP 9876
let blenderError = "";
let blenderScriptsReady = false;
const BLENDER_TOOL_NAMES = new Set([
  "get_scene_info", "get_object_info", "execute_blender_code", "get_viewport_screenshot",
  "blender_export_fbx", "blender_import_fbx", "blender_export_obj", "blender_import_obj",
  "blender_mesh_dump", "blender_send_to_studio", "blender_execute_code",
  "blender_get_scene_info", "blender_get_object_info", "blender_screenshot",
  "export_blender_fbx", "import_blender_fbx",
]);
function btool(name, description, props, required) {
  return { name, server: "blender", description, inputSchema: { type: "object", properties: props || {}, required: required || [] } };
}
const BLENDER_TOOLS = [
  btool("get_scene_info", "Inspect the live Blender scene (objects, cameras, lights, collections).", {}, []),
  btool("get_object_info", "Details for one object in the Blender scene.", { name: { type: "string" } }, ["name"]),
  btool("execute_blender_code", "Run Python (bpy) inside Blender. Prefer the named blender_* tools.", { code: { type: "string" } }, ["code"]),
  btool("get_viewport_screenshot", "Capture the Blender 3D viewport.", { max_size: { type: "integer" } }, []),
  btool("blender_send_to_studio", "ONE SHOT: dump the live Blender meshes and import them into Roblox Studio as Workspace.PLAZCODE_Imported. No filepath needed.", { objects: { type: "array", items: { type: "string" } }, dest: { type: "string" }, scale: { type: "number" } }, []),
  btool("blender_export_fbx", "Export meshes to an FBX (Forward -Z, Up Y). filepath optional. Also dumps meshes so blender_send_to_studio / asset_bridge_import can run with no path.", { filepath: { type: "string" }, objects: { type: "array", items: { type: "string" } } }, []),
  btool("blender_import_fbx", "Import an FBX into the live Blender scene. filepath optional — defaults to the last PlazCode export.", { filepath: { type: "string" } }, []),
  btool("blender_export_obj", "Export selected/all meshes to OBJ. filepath optional.", { filepath: { type: "string" }, objects: { type: "array", items: { type: "string" } } }, []),
  btool("blender_import_obj", "Import an OBJ into the live Blender scene.", { filepath: { type: "string" } }, ["filepath"]),
  btool("blender_add_cube", "Add a cube.", { name: { type: "string" }, size: { type: "number" }, location: { type: "array", items: { type: "number" } } }, []),
  btool("blender_add_sphere", "Add a UV sphere.", { name: { type: "string" }, radius: { type: "number" }, location: { type: "array" } }, []),
  btool("blender_add_cylinder", "Add a cylinder.", { name: { type: "string" }, radius: { type: "number" }, depth: { type: "number" }, location: { type: "array" } }, []),
  btool("blender_add_cone", "Add a cone.", { name: { type: "string" }, radius: { type: "number" }, depth: { type: "number" }, location: { type: "array" } }, []),
  btool("blender_add_plane", "Add a plane.", { name: { type: "string" }, size: { type: "number" }, location: { type: "array" } }, []),
  btool("blender_add_torus", "Add a torus.", { name: { type: "string" }, location: { type: "array" } }, []),
  btool("blender_add_monkey", "Add Suzanne (monkey head).", { name: { type: "string" }, location: { type: "array" } }, []),
  btool("blender_add_empty", "Add an Empty (use as a group parent).", { name: { type: "string" }, location: { type: "array" } }, []),
  btool("blender_add_camera", "Add a camera.", { name: { type: "string" }, location: { type: "array" } }, []),
  btool("blender_add_light", "Add a light (SUN/POINT/SPOT/AREA).", { name: { type: "string" }, type: { type: "string" }, location: { type: "array" }, energy: { type: "number" } }, []),
  btool("blender_group", "Group objects: parent them to a new Empty and put them in a collection of the same name.", { name: { type: "string", description: "Group name" }, objects: { type: "array", items: { type: "string" }, description: "Object names; omit = selected/all meshes" } }, []),
  btool("blender_ungroup", "Ungroup: clear parent, keep world transforms, remove the group Empty.", { name: { type: "string" } }, []),
  btool("blender_parent", "Parent objects under an existing object/Empty.", { parent: { type: "string" }, objects: { type: "array", items: { type: "string" } } }, ["parent"]),
  btool("blender_unparent", "Clear parent, keep world transforms.", { objects: { type: "array", items: { type: "string" } } }, []),
  btool("blender_join", "Join mesh objects into one.", { objects: { type: "array", items: { type: "string" } }, name: { type: "string" } }, []),
  btool("blender_move_to_collection", "Move objects into a collection (created if missing).", { collection: { type: "string" }, objects: { type: "array", items: { type: "string" } } }, []),
  btool("blender_list_collections", "List collections and their objects.", {}, []),
  btool("blender_list_objects", "List every object: type, location, parent, collections.", {}, []),
  btool("blender_delete", "Delete objects.", { name: { type: "string" }, objects: { type: "array", items: { type: "string" } } }, []),
  btool("blender_duplicate", "Duplicate objects.", { name: { type: "string" }, objects: { type: "array", items: { type: "string" } } }, []),
  btool("blender_rename", "Rename an object.", { name: { type: "string" }, new_name: { type: "string" } }, ["new_name"]),
  btool("blender_select", "Select objects by name.", { name: { type: "string" }, objects: { type: "array", items: { type: "string" } } }, []),
  btool("blender_transform", "Set location / rotation (radians) / scale.", { name: { type: "string" }, objects: { type: "array" }, location: { type: "array" }, rotation: { type: "array" }, scale: { type: "array" } }, []),
  btool("blender_apply_transforms", "Apply rotation/scale (and optional location).", { objects: { type: "array" }, location: { type: "boolean" }, rotation: { type: "boolean" }, scale: { type: "boolean" } }, []),
  btool("blender_set_origin", "Set object origin (ORIGIN_GEOMETRY, ORIGIN_CURSOR, ORIGIN_CENTER_OF_MASS).", { name: { type: "string" }, type: { type: "string" } }, []),
  btool("blender_shade_smooth", "Shade smooth.", { name: { type: "string" }, objects: { type: "array" } }, []),
  btool("blender_set_material", "Assign a Principled BSDF material. color = [r,g,b] or [r,g,b,a] 0–1.", { name: { type: "string" }, material: { type: "string" }, color: { type: "array" } }, []),
  // ── Material toolkit ──
  btool("blender_material_create", "Create a node-based material (optionally assigning it). Either a preset, explicit PBR values, or both. color = [r,g,b(,a)] 0–1, [r,g,b] 0–255, or '#rrggbb'.", { material: { type: "string" }, preset: { type: "string", description: "metal, steel, iron, chrome, gold, silver, copper, bronze, brass, plastic, rubber, ceramic, concrete, asphalt, wood, marble, fabric, leather, glass, frosted_glass, water, ice, emissive, neon, lava, hologram, ghost, toon, roblox_plastic, roblox_metal, roblox_glass" }, color: { type: "array" }, metallic: { type: "number" }, roughness: { type: "number" }, ior: { type: "number" }, transmission: { type: "number" }, alpha: { type: "number" }, emission: { type: "array" }, emission_strength: { type: "number" }, coat: { type: "number" }, sheen: { type: "number" }, blend: { type: "string", description: "BLEND / HASHED / OPAQUE" }, name: { type: "string", description: "object to assign to" }, objects: { type: "array" }, append_slot: { type: "boolean" } }, ["material"]),
  btool("blender_material_preset", "Create a material from a named preset in one call (see blender_material_create for the list) and assign it.", { material: { type: "string" }, preset: { type: "string" }, name: { type: "string" }, objects: { type: "array" }, color: { type: "array" } }, ["preset"]),
  btool("blender_material_set", "Change values on an EXISTING material (color, metallic, roughness, emission, alpha, ior, transmission, coat, sheen, blend).", { material: { type: "string" }, color: { type: "array" }, metallic: { type: "number" }, roughness: { type: "number" }, emission: { type: "array" }, emission_strength: { type: "number" }, alpha: { type: "number" }, transmission: { type: "number" }, ior: { type: "number" }, coat: { type: "number" }, sheen: { type: "number" }, blend: { type: "string" } }, ["material"]),
  btool("blender_material_assign", "Assign an existing material to objects (all slots, one slot, or append a new slot).", { material: { type: "string" }, name: { type: "string" }, objects: { type: "array" }, slot: { type: "integer" }, append: { type: "boolean" } }, ["material"]),
  btool("blender_material_list", "List every material: users, Principled values, plus the known preset names.", {}, []),
  btool("blender_material_inspect", "Dump one material completely: Principled BSDF inputs, linked inputs, node graph, users.", { material: { type: "string" }, name: { type: "string" } }, []),
  btool("blender_material_remove", "Delete a material from the file.", { material: { type: "string" } }, ["material"]),
  btool("blender_material_noise", "Add a procedural texture to a material (noise, voronoi, wave, checker, brick, gradient) driving bump, base color, roughness or emission.", { material: { type: "string" }, type: { type: "string" }, affect: { type: "string", description: "bump | base_color | roughness | emission" }, scale: { type: "number" }, detail: { type: "number" }, roughness: { type: "number" }, distortion: { type: "number" }, strength: { type: "number" }, color_a: { type: "array" }, color_b: { type: "array" }, replace: { type: "boolean" } }, ["material"]),
  btool("blender_material_image", "Wire an image file into a material slot (base_color, roughness, metallic, normal, emission).", { material: { type: "string" }, path: { type: "string" }, slot: { type: "string" }, strength: { type: "number" }, alpha_to_alpha: { type: "boolean" }, colorspace: { type: "string" } }, ["material", "path"]),
  btool("blender_material_pbr", "Build a full PBR graph from map files (base_color/albedo + optional orm, roughness, metallic, normal, emission) with correct Non-Color colorspaces.", { material: { type: "string" }, base_color: { type: "string" }, albedo: { type: "string" }, orm: { type: "string" }, roughness: { type: "string" }, metallic: { type: "string" }, normal: { type: "string" }, emission: { type: "string" } }, ["material"]),
  btool("blender_add_modifier", "Add a modifier: SUBSURF, BEVEL, SOLIDIFY, MIRROR, ARRAY, BOOLEAN, DECIMATE. apply=true to apply.", { name: { type: "string" }, type: { type: "string" }, levels: { type: "integer" }, apply: { type: "boolean" }, target: { type: "string" } }, []),
  btool("blender_boolean", "Boolean one mesh with another (DIFFERENCE/UNION/INTERSECT) and apply.", { name: { type: "string" }, target: { type: "string" }, operation: { type: "string" } }, ["target"]),
  btool("blender_clear_scene", "Delete objects. keep = names to leave.", { keep: { type: "array", items: { type: "string" } } }, []),
  btool("blender_add_grid", "Add a grid.", { name: { type: "string" }, size: { type: "number" }, location: { type: "array" } }, []),
  btool("blender_add_text", "Add 3D text. text=string, extrude=thickness.", { name: { type: "string" }, text: { type: "string" }, extrude: { type: "number" }, location: { type: "array" } }, []),
  btool("blender_translate", "Move objects by offset [x,y,z] (relative).", { offset: { type: "array" }, name: { type: "string" }, objects: { type: "array" } }, []),
  btool("blender_rotate", "Set rotation in DEGREES [x,y,z]. add=true to add.", { rotation_deg: { type: "array" }, add: { type: "boolean" }, name: { type: "string" }, objects: { type: "array" } }, []),
  btool("blender_set_dimensions", "Set object size in meters [x,y,z].", { dimensions: { type: "array" }, name: { type: "string" } }, []),
  btool("blender_origin_to_bottom", "Put origin at the lowest point (Roblox feet).", { name: { type: "string" }, objects: { type: "array" } }, []),
  btool("blender_drop_to_ground", "Move objects so the lowest vertex sits on Z=0.", { name: { type: "string" }, objects: { type: "array" } }, []),
  btool("blender_array", "Duplicate along offset, count times.", { count: { type: "integer" }, offset: { type: "array" }, objects: { type: "array" } }, []),
  btool("blender_mirror", "Mirror-duplicate across X/Y/Z.", { axis: { type: "string" }, objects: { type: "array" } }, []),
  btool("blender_triangulate", "Convert faces to triangles (needed before Studio).", { objects: { type: "array" } }, []),
  btool("blender_apply_modifiers", "Apply every modifier so dump/export sees the result.", { objects: { type: "array" } }, []),
  btool("blender_merge", "Merge-by-distance (remove doubles).", { distance: { type: "number" }, objects: { type: "array" } }, []),
  btool("blender_recalc_normals", "Recalculate outside normals.", { objects: { type: "array" } }, []),
  btool("blender_hide", "Hide objects.", { name: { type: "string" }, objects: { type: "array" } }, []),
  btool("blender_unhide", "Unhide objects (omit names = all).", { name: { type: "string" }, objects: { type: "array" } }, []),
  btool("blender_undo", "Undo last Blender action.", {}, []),
  btool("blender_stats", "Vertex/face/modifier counts.", { objects: { type: "array" } }, []),
  btool("blender_get_selection", "Names of selected objects.", {}, []),
  btool("blender_uv_unwrap", "Smart UV project.", { objects: { type: "array" } }, []),
  btool("blender_look_at", "Point an object/camera at a target or location.", { name: { type: "string" }, target: { type: "string" }, location: { type: "array" } }, []),
  btool("blender_align_camera", "Align the scene camera to an axis (front/back/left/right/top/bottom/iso) looking at a target or the selection.", { axis: { type: "string" }, distance: { type: "number" }, target: { type: "string" }, name: { type: "string" } }, []),
  btool("blender_align_camera_axis", "Same as blender_align_camera.", { axis: { type: "string" }, distance: { type: "number" }, target: { type: "string" }, name: { type: "string" } }, []),
  btool("blender_view_axis", "Align the 3D viewport to FRONT/BACK/LEFT/RIGHT/TOP/BOTTOM (or iso via camera).", { axis: { type: "string" } }, []),
  btool("blender_camera_to_view", "Move the scene camera to match the current 3D viewport.", {}, []),
  btool("blender_set_camera_lens", "Set camera focal length, clip planes, or orthographic mode.", { name: { type: "string" }, lens: { type: "number" }, clip_start: { type: "number" }, clip_end: { type: "number" }, ortho: { type: "boolean" }, ortho_scale: { type: "number" } }, []),
  btool("blender_scale", "Scale selected/named objects. scale:[x,y,z] or a number. multiply=true multiplies current scale.", { name: { type: "string" }, scale: { type: "array" }, factor: { type: "array" }, multiply: { type: "boolean" } }, []),
  btool("blender_bevel", "Bevel mesh edges in edit mode.", { name: { type: "string" }, width: { type: "number" }, segments: { type: "number" } }, []),
  btool("blender_solidify", "Add a Solidify modifier (thickness).", { name: { type: "string" }, thickness: { type: "number" } }, []),
  btool("blender_extrude", "Extrude the mesh along normals.", { name: { type: "string" }, distance: { type: "number" } }, []),
  btool("blender_add_curve", "Add a Bezier curve.", { name: { type: "string" }, location: { type: "array" } }, []),
  btool("blender_add_armature", "Add an armature (single bone).", { name: { type: "string" }, location: { type: "array" } }, []),
  btool("blender_keyframe_insert", "Insert a keyframe on location/rotation/scale (or data_path) at frame.", { name: { type: "string" }, frame: { type: "number" }, data_path: { type: "string" } }, []),
  btool("blender_set_frame", "Set the current scene frame.", { frame: { type: "number" } }, []),
  btool("blender_set_active_camera", "Make a camera the scene camera.", { name: { type: "string" } }, []),
  btool("blender_track_to", "TRACK_TO constraint from selected objects toward target.", { target: { type: "string" }, name: { type: "string" } }, ["target"]),
  btool("blender_cursor_to_selected", "Move the 3D cursor to the selection midpoint.", { name: { type: "string" } }, []),
  btool("blender_randomize_transform", "Jitter location/rotation/scale of selected objects.", { name: { type: "string" }, location: { type: "number" }, rotation: { type: "number" }, scale: { type: "number" }, seed: { type: "number" } }, []),
  btool("blender_hide_render", "Hide (or unhide) objects from render.", { name: { type: "string" }, hide: { type: "boolean" } }, []),
  btool("blender_subdivision", "Add a Subdivision Surface modifier.", { name: { type: "string" }, levels: { type: "number" }, render_levels: { type: "number" } }, []),
  btool("blender_origin_to_geometry", "Set origin to geometry for selected objects.", { name: { type: "string" } }, []),
];
for (const t of BLENDER_TOOLS) BLENDER_TOOL_NAMES.add(t.name);

function blenderServers(list) {
  const rest = (Array.isArray(list) ? list : []).filter((s) => s && s.id !== "blender");
  if (blenderAddon) {
    rest.push({
      id: "blender", name: "Blender",
      alive: true, tools: BLENDER_TOOLS.length,
    });
  }
  return rest;
}
function mergeBlenderTools(tools) {
  const base = Array.isArray(tools) ? tools.slice() : [];
  if (!blenderAddon) return base;
  const have = new Set(base.map((t) => t && t.name));
  for (const t of BLENDER_TOOLS) if (!have.has(t.name)) base.push(t);
  return base;
}

function log(...a) {
  console.log("[plazcode-bg]", ...a);
}

// ── WebSocket lifecycle ─────────────────────────────────────────────────
async function connect() {
  try { await ensurePairing(true); } catch (error) {
    log(error.message || "Agent unavailable for automatic pairing");
    scheduleReconnect();
    return;
  }
  if (ws && (ws.readyState === WebSocket.OPEN || ws.readyState === WebSocket.CONNECTING)) {
    return;
  }
  clearTimeout(reconnectTimer);
  const url = engineUrl();
  let sock;
  try {
    sock = new WebSocket(url, pairingProtocols());
  } catch (e) {
    log("WebSocket ctor failed", e);
    scheduleReconnect();
    return;
  }
  ws = sock;

  sock.onopen = () => {
    if (sock !== ws) return;
    connected = true;
    reconnectDelay = RECONNECT_MIN;
    lastMessageAt = Date.now();
    log(`connected to ${engineLabel()} bridge (${url})`);
    startHeartbeat();
    refreshProcStatus();
    broadcastStatus();
  };

  sock.onmessage = (ev) => {
    if (sock !== ws) return;
    lastMessageAt = Date.now();
    let msg;
    try {
      msg = JSON.parse(ev.data);
    } catch {
      return;
    }
    handleBridgeMessage(msg);
  };

  sock.onclose = () => {
    if (sock !== ws) return;
    connected = false;
    mcpAlive = false;
    studioConnected = null;
    studioApp = null;
    studioProc = null;
    robloxEditorConnected = false;
    toolsCache = [];
    serversCache = [];
    stopHeartbeat();
    failAllPending("bridge connection closed");
    broadcastStatus();
    scheduleReconnect();
  };

  sock.onerror = () => {
    if (sock !== ws) return;
    // onclose will follow; nothing to do here but avoid an unhandled error.
    try { sock.close(); } catch {}
  };
}

function scheduleReconnect() {
  clearTimeout(reconnectTimer);
  reconnectTimer = setTimeout(connect, reconnectDelay);
  reconnectDelay = Math.min(reconnectDelay * 1.7, RECONNECT_MAX);
}

function startHeartbeat() {
  stopHeartbeat();
  heartbeatTimer = setInterval(() => {
    if (connected) {
      // Half-open socket: the WS still reports OPEN but nothing comes through.
      // The pong (and every other frame) refreshes lastMessageAt; if it has
      // gone stale, drop the dead socket so onclose triggers a reconnect.
      const toolPending = [...pending.values()].some((p) => p.type === "call_tool");
      if (lastMessageAt && Date.now() - lastMessageAt > STALE_SOCKET_MS) {
        if (toolPending) return; // execute_luau owns the helper — pong resumes after it
        log("socket stale, forcing reconnect");
        try { ws.close(); } catch {}
        return;
      }
      // Keeps the MV3 service worker alive AND detects a half-open socket.
      // Use short timeout so pending ping doesn't leak for 130s
      send({ type: "ping" }, 12000).catch(() => {});
      refreshStudioStatus();
      // ── MCP auto-heal (v1.12) ────────────────────────────────────────────
      // The StudioMCP helper the agent spawns can die on its own (Studio
      // update, sleep/resume, crash). The agent only recycles it when a TOOL
      // call proves the helper dead - so between calls the bar kept showing
      // "connected" with a corpse helper and every command failed. If the
      // helper has been dead for two consecutive heartbeats, restart it
      // proactively (max once per 3 min so a legitimately closed Studio can't
      // cause a restart loop - the agent refuses when Studio's MCP option is
      // off, and that answer must win).
      if ((engine === "roblox" || engine === "anim") && !toolPending) {
        // Studio closed / MCP plugin off: do not restart-loop the helper.
        if (studioProc === false || studioApp === false) {
          mcpDownStreak = 0;
        } else if (!mcpAlive) {
          mcpDownStreak++;
          // Idle heal: one missed heartbeat, 30s cooldown. Never heal mid-tool.
          if (mcpDownStreak >= 1 && Date.now() - lastMcpHealAt > 30000) {
            lastMcpHealAt = Date.now();
            mcpDownStreak = 0;
            log("MCP helper down across heartbeats - auto-restarting Studio MCP");
            send({ type: "restart_mcp" }, 30000).then((r) => {
              if (r && r.ok) {
                send({ type: "list_tools" }, 10000).catch(() => {});
                refreshStudioStatus();
              }
            }).catch(() => {});
          }
        } else {
          mcpDownStreak = 0;
        }
      }
    }
  }, HEARTBEAT_MS);
}
// Auto-heal state (see startHeartbeat).
let mcpDownStreak = 0;
let lastMcpHealAt = 0;

function stopHeartbeat() {
  clearInterval(heartbeatTimer);
  heartbeatTimer = null;
}

// Resolve once the socket is OPEN, or false after `timeout` ms.
function waitForConnection(timeout = 20000) {
  return new Promise((resolve) => {
    if (connected && ws && ws.readyState === WebSocket.OPEN) return resolve(true);
    connect(); // nudge a (re)connection - important after a worker wake-up
    const t0 = Date.now();
    const iv = setInterval(() => {
      if (connected && ws && ws.readyState === WebSocket.OPEN) {
        clearInterval(iv);
        resolve(true);
      } else if (Date.now() - t0 > timeout) {
        clearInterval(iv);
        resolve(false);
      }
    }, 100);
  });
}

// ── request/response over the socket ────────────────────────────────────
async function send(obj, timeout = REQUEST_TIMEOUT_DEFAULT) {
  // The MV3 service worker can be suspended; the first message after a wake-up
  // arrives before the socket has re-opened. Wait for it instead of failing -
  // otherwise Kimi wrongly hears "bridge offline".
  if (!connected || !ws || ws.readyState !== WebSocket.OPEN) {
    await waitForConnection(20000);
  }
  const attempt = () => new Promise((resolve) => {
    if (!connected || !ws || ws.readyState !== WebSocket.OPEN) {
      resolve({ ok: false, kind: "disconnected", error: "bridge not connected" });
      return;
    }
    const id = nextId++;
    const payload = { ...obj, id };
    const timer = setTimeout(() => {
      if (pending.has(id)) {
        pending.delete(id);
        resolve({ ok: false, kind: "timeout", error: "bridge did not respond in time" });
      }
    }, timeout);
    pending.set(id, { resolve, timer, type: obj.type });
    try {
      ws.send(JSON.stringify(payload));
    } catch (e) {
      clearTimeout(timer);
      pending.delete(id);
      resolve({ ok: false, kind: "disconnected", error: String(e) });
    }
  });
  let r = await attempt();
  if (r && r.kind === "disconnected") {
    await waitForConnection(15000);
    r = await attempt();
  }
  return r;
}

// Ask the bridge whether a Roblox Studio instance is actually connected to the
// MCP server. Broadcasts only on change so the UI updates promptly but quietly.
let studioProbing = false;
async function refreshStudioStatus() {
  if (studioProbing || !connected) return;
  if ([...pending.values()].some((p) => p.type === "call_tool")) return;
  studioProbing = true;
  try {
    const r = await send({ type: "studio_status" }, 12000);
    const v = r && r.ok && typeof r.studio === "boolean" ? r.studio : null;
    if (engine === "roblox" || engine === "anim") robloxEditorConnected = v === true;
    // local readiness comes from the agent's /api/status (local_ready), not editor probes
    if (v !== studioConnected) {
      studioConnected = v;
      broadcastStatus();
    } else {
      // The probe result can change independently of the tri-state cache when a
      // timeout returns null, so still publish the strict editor flag.
      broadcastStatus();
    }
  } finally {
    studioProbing = false;
  }
}

function handleBridgeMessage(msg) {
  if ("studio" in msg && (typeof msg.studio === "boolean" || msg.studio === null)) {
    studioConnected = msg.studio;
  }
  if ("studio_app" in msg && (typeof msg.studio_app === "boolean" || msg.studio_app === null)) {
    studioApp = msg.studio_app;
  }
  if ("studio_proc" in msg && (typeof msg.studio_proc === "boolean" || msg.studio_proc === null)) {
    studioProc = msg.studio_proc;
  }
  if (msg.type === "studio_status") {
    const online = studioConnected === true;
    if (engine === "roblox" || engine === "anim") robloxEditorConnected = online;
    resolvePending(msg.id, { ok: true, studio: online });
    broadcastStatus();
    return;
  }
  if (msg.type === "connected") {
    mcpAlive = !!msg.mcp_alive;
    if (Array.isArray(msg.tools)) toolsCache = msg.tools;
    if (Array.isArray(msg.servers)) serversCache = msg.servers;
    const online = msg.studio === true;
    if (engine === "roblox" || engine === "anim") robloxEditorConnected = online;
    broadcastStatus();
    return;
  }
  if (msg.type === "pong") {
    resolvePending(msg.id, { ok: true });
    return;
  }
  if (msg.type === "tools") {
    if (Array.isArray(msg.tools)) toolsCache = msg.tools;
    if (Array.isArray(msg.servers)) serversCache = msg.servers;
    mcpAlive = !!msg.mcp_alive;
    const online = msg.studio === true;
    if (engine === "roblox" || engine === "anim") robloxEditorConnected = online;
    resolvePending(msg.id, { ok: !!msg.ok, tools: toolsCache, studio: online });
    broadcastStatus();
    return;
  }
  if (msg.type === "tool_result") {
    resolvePending(msg.id, msg.ok
      ? { ok: true, text: msg.text, images: msg.images || [] }
      : { ok: false, kind: msg.kind, error: msg.error });
    return;
  }
  if (msg.type === "mcp_status") {
    mcpAlive = !!msg.alive;
    if (Array.isArray(msg.tools)) toolsCache = msg.tools;
    if (Array.isArray(msg.servers)) {
      serversCache = msg.servers;
      const rbx = serversCache.find((x) => x.id === "roblox" || x.id === "studio");
      if (rbx) robloxEditorConnected = !!rbx.alive;
      const loc = serversCache.find((x) => x.id === "local");
      if (loc) localReady = !!loc.alive;
    }
    resolvePending(msg.id, { ok: !!msg.ok, alive: mcpAlive, error: msg.error });
    broadcastStatus();
    return;
  }
  if (msg.type === "server_changed") {
    // The bridge acks, then restarts itself to reload config.json. The socket
    // will drop right after this - the content script shows a spinner until the
    // reconnect lands and a fresh status arrives.
    resolvePending(msg.id, { ok: !!msg.ok, error: msg.error, restarting: !!msg.restarting });
    return;
  }
  if (msg.type === "error") {
    resolvePending(msg.id, { ok: false, error: msg.error });
    return;
  }
}

function resolvePending(id, value) {
  const p = pending.get(id);
  if (!p) return;
  clearTimeout(p.timer);
  pending.delete(id);
  p.resolve(value);
}

function failAllPending(reason) {
  for (const [, p] of pending) {
    clearTimeout(p.timer);
    p.resolve({ ok: false, kind: "disconnected", error: reason });
  }
  pending.clear();
}

// ── status push to any open DeepSeek tab + popup ─────────────────────────
function statusObj() {
  return {
    type: "rs-status", connected, mcpAlive, studio: studioConnected, studioApp, studioProc,
    robloxProc, roblox_connected: robloxEditorConnected,
    local_connected: localReady, local_full: localFull,
    local_root: localRoot,
    tools: mergeBlenderTools(toolsCache).length,
    servers: blenderServers(serversCache), engine,
    blender: blenderAddon, blender_error: blenderError || undefined,
  };
}

async function refreshProcStatus() {
  try {
    const r = await bridgeFetch(`${RUST_ROBLOX_HTTP}/api/status`, { method: "GET" });
    if (!r.ok) return;
    const j = await r.json();
    const nr = !!j.roblox_proc;
    const nl = j.local_ready === true;
    const nf = j.local_full === true;
    const nrRoot = typeof j.local_root === "string" ? j.local_root : localRoot;
    const changed = nr !== robloxProc || nl !== localReady || nf !== localFull || nrRoot !== localRoot;
    robloxProc = nr;
    localReady = nl;
    localFull = nf;
    localRoot = nrRoot;
    // One-shot re-sync: if the agent restarted with FULL off but the user's
    // persisted toggle says ON, re-apply their choice once.
    if (!fullSyncedOnce) {
      fullSyncedOnce = true;
      try {
        chrome.storage.local.get("rs-local-full", (o) => {
          const want = o && o["rs-local-full"];
          if (typeof want === "boolean" && want !== nf) {
            bridgeFetch("http://127.0.0.1:3000/api/local-full", {
              method: "POST", headers: { "Content-Type": "application/json" },
              body: JSON.stringify({ enabled: want }),
            }).then((r2) => r2.json()).then((j2) => { localFull = j2.local_full === true; broadcastStatus(); }).catch(() => {});
          }
        });
      } catch {}
    }
    if (changed) broadcastStatus();
  } catch {}
}

function broadcastStatus() {
  chrome.runtime.sendMessage(statusObj()).catch(() => {});
  chrome.tabs.query({ url: PROVIDER_URLS }, (tabs) => {
    for (const t of tabs) chrome.tabs.sendMessage(t.id, statusObj()).catch(() => {});
  });
}


// ── Web tools (search + fetch) ──────────────────────────────────────────────
// Health notes (why this is not one DDG call anymore):
//  * html.duckduckgo.com/html/ is the endpoint PlazCode used to scrape with a
//    "PlazCode/1.0" UA. DDG now treats that as an anomaly: it answers 202/403 with a
//    challenge page that contains ZERO .result__a anchors, so the old parser
//    returned [] and the tool reported "no results" on every query.
//  * A browser UA + Accept-Language + Referer is required for the same URL to
//    serve real results, and even then DDG rate-limits datacenter IPs.
//  * So: try several independent backends in order, use a REAL browser UA, and
//    fall back to a generic anchor parser per backend (markup drifts; a
//    changed class name must not zero out the whole tool).
// Every backend failure is collected and reported, so "it doesn't work" is
// always accompanied by WHY (status codes included) instead of a bare "no
// results for X".
const BROWSER_UA =
  "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36";
const WEB_FETCH_TIMEOUT = 20000;
const WEB_SEARCH_TIMEOUT = 12000;

function webHeaders(extra, referer) {
  const h = {
    "User-Agent": BROWSER_UA,
    Accept: "text/html,application/xhtml+xml,application/xml;q=0.9,text/plain;q=0.8,*/*;q=0.7",
    "Accept-Language": "en-US,en;q=0.9",
    "Cache-Control": "no-cache",
  };
  if (referer) h.Referer = referer;
  return Object.assign(h, extra || {});
}

// A hung fetch is worse than a failed one: the content script's bg() has no
// timeout of its own, so an endpoint that never answers used to spin the tool
// forever. AbortController gives every request a hard deadline.
async function fetchWithTimeout(url, opts, ms) {
  const ctrl = typeof AbortController === "function" ? new AbortController() : null;
  const timer = ctrl ? setTimeout(() => { try { ctrl.abort(); } catch {} }, ms || WEB_FETCH_TIMEOUT) : null;
  try {
    return await fetch(url, Object.assign({ redirect: "follow" }, opts || {}, ctrl ? { signal: ctrl.signal } : {}));
  } finally {
    if (timer) clearTimeout(timer);
  }
}

const ENTITIES = {
  nbsp: " ", amp: "&", lt: "<", gt: ">", quot: '"', apos: "'", "#39": "'", "#x27": "'",
  mdash: "—", ndash: "–", hellip: "…", rsquo: "’", lsquo: "‘", ldquo: "“", rdquo: "”",
  middot: "·", times: "×", deg: "°", copy: "©", reg: "®", trade: "™", euro: "€", pound: "£",
};
function decodeEntities(s) {
  // Numeric forms first, then named. &amp; is decoded LAST via a single pass so
  // a literal "&amp;lt;" does not turn into "<" (double-decoding).
  return String(s || "")
    .replace(/&#x([0-9a-f]+);/gi, (_, h) => { try { return String.fromCodePoint(parseInt(h, 16)); } catch { return " "; } })
    .replace(/&#(\d+);/g, (_, d) => { try { return String.fromCodePoint(Number(d)); } catch { return " "; } })
    .replace(/&([a-z#0-9x]+);/gi, (m, name) => {
      const key = String(name).toLowerCase();
      if (key === "amp") return "&";
      return Object.prototype.hasOwnProperty.call(ENTITIES, key) ? ENTITIES[key] : m;
    });
}

function stripTags(html) {
  return decodeEntities(String(html || "").replace(/<[^>]*>/g, " ")).replace(/\s+/g, " ").trim();
}

// DDG wraps every result link as /l/?uddg=<urlencoded>&rut=…
function unwrapDdg(href) {
  let h = String(href || "").trim();
  if (h.startsWith("//")) h = "https:" + h;
  const m = h.match(/[?&]uddg=([^&]+)/);
  if (m) { try { return decodeURIComponent(m[1]); } catch { return h; } }
  const m2 = h.match(/[?&]url=([^&]+)/);
  if (m2 && /duckduckgo\.com\/l\//.test(h)) { try { return decodeURIComponent(m2[1]); } catch {} }
  return h;
}

function cleanHits(list, n, engineHost) {
  const out = [];
  const seen = new Set();
  for (const r of list) {
    let url = String((r && r.url) || "").trim();
    const title = stripTags((r && r.title) || "");
    if (!/^https?:\/\//i.test(url)) continue;
    if (engineHost && url.includes(engineHost)) continue;
    if (!title || title.length < 3) continue;
    const key = url.replace(/[#?].*$/, "").replace(/\/+$/, "");
    if (seen.has(key)) continue;
    seen.add(key);
    out.push({ title: title.slice(0, 180), url });
    if (out.length >= n) break;
  }
  return out;
}

// Last-resort parser: ANY anchor with an http(s) href and real text. Used when
// a backend's markup changed (or is unknown) so the tool still returns hits.
function parseGenericAnchors(html, n, engineHost) {
  const hits = [];
  const re = /<a\b[^>]*href=["']([^"']+)["'][^>]*>([\s\S]*?)<\/a>/gi;
  let m;
  while ((m = re.exec(String(html || ""))) !== null) {
    const url = unwrapDdg(m[1]);
    const title = stripTags(m[2]);
    if (!title || title.length < 12 || title.length > 180) continue;
    hits.push({ url, title });
  }
  return cleanHits(hits, n, engineHost);
}

function parseDdgHtml(html, n) {
  const hits = [];
  const re = /<a\b[^>]*class="[^"]*result__a[^"]*"[^>]*href=["']([^"']+)["'][^>]*>([\s\S]*?)<\/a>/gi;
  let m;
  while ((m = re.exec(String(html || ""))) !== null) hits.push({ url: unwrapDdg(m[1]), title: m[2] });
  // class before href (older markup) — attribute order is not guaranteed.
  if (!hits.length) {
    const re2 = /<a\b[^>]*href=["']([^"']+)["'][^>]*class="[^"]*result__a[^"]*"[^>]*>([\s\S]*?)<\/a>/gi;
    while ((m = re2.exec(String(html || ""))) !== null) hits.push({ url: unwrapDdg(m[1]), title: m[2] });
  }
  const clean = cleanHits(hits, n, "duckduckgo.com");
  return clean.length ? clean : parseGenericAnchors(html, n, "duckduckgo.com");
}

function parseDdgLite(html, n) {
  const hits = [];
  const re = /<a\b[^>]*class="[^"]*result-link[^"]*"[^>]*href=["']([^"']+)["'][^>]*>([\s\S]*?)<\/a>/gi;
  let m;
  while ((m = re.exec(String(html || ""))) !== null) hits.push({ url: unwrapDdg(m[1]), title: m[2] });
  const clean = cleanHits(hits, n, "duckduckgo.com");
  return clean.length ? clean : parseGenericAnchors(html, n, "duckduckgo.com");
}

function parseMojeek(html, n) {
  const hits = [];
  const re = /<a\b[^>]*class="[^"]*\bob\b[^"]*"[^>]*href=["']([^"']+)["'][^>]*>([\s\S]*?)<\/a>/gi;
  let m;
  while ((m = re.exec(String(html || ""))) !== null) hits.push({ url: m[1], title: m[2] });
  if (!hits.length) {
    const re2 = /<h2>\s*<a\b[^>]*href=["']([^"']+)["'][^>]*>([\s\S]*?)<\/a>/gi;
    while ((m = re2.exec(String(html || ""))) !== null) hits.push({ url: m[1], title: m[2] });
  }
  const clean = cleanHits(hits, n, "mojeek.com");
  return clean.length ? clean : parseGenericAnchors(html, n, "mojeek.com");
}

// Wikipedia has a real JSON API with CORS — not scraped, so it never breaks.
// Not a general web search, but an excellent last resort for API/property
// questions and it keeps the tool useful when every scraper is blocked.
function parseWikipedia(json, n) {
  const out = [];
  try {
    const rows = (JSON.parse(json).query || {}).search || [];
    for (const r of rows) {
      out.push({
        title: r.title + " — Wikipedia",
        url: "https://en.wikipedia.org/wiki/" + encodeURIComponent(String(r.title).replace(/ /g, "_")),
      });
      if (out.length >= n) break;
    }
  } catch {}
  return out;
}

const SEARCH_BACKENDS = [
  { id: "duckduckgo", url: (q) => "https://html.duckduckgo.com/html/?q=" + encodeURIComponent(q), parse: parseDdgHtml, referer: "https://duckduckgo.com/" },
  { id: "ddg-lite", url: (q) => "https://lite.duckduckgo.com/lite/?q=" + encodeURIComponent(q), parse: parseDdgLite, referer: "https://lite.duckduckgo.com/" },
  { id: "mojeek", url: (q) => "https://www.mojeek.com/search?q=" + encodeURIComponent(q), parse: parseMojeek, referer: "https://www.mojeek.com/" },
  { id: "wikipedia", url: (q) => "https://en.wikipedia.org/w/api.php?action=query&list=search&format=json&srlimit=5&srsearch=" + encodeURIComponent(q), parse: parseWikipedia, json: true, referer: "https://en.wikipedia.org/" },
];

// Try every backend until one yields hits. Returns { hits, backend, notes }.
async function webSearch(query, limit) {
  const q = String(query || "").trim();
  const n = Math.max(1, Math.min(8, Number(limit) || 3));
  if (!q) return { hits: [], backend: null, notes: ["empty query"] };
  const notes = [];
  for (const b of SEARCH_BACKENDS) {
    try {
      const extra = b.json ? { Accept: "application/json,text/plain,*/*" } : null;
      const res = await fetchWithTimeout(b.url(q), { headers: webHeaders(extra, b.referer) }, WEB_SEARCH_TIMEOUT);
      if (!res.ok) { notes.push(`${b.id}: HTTP ${res.status}`); continue; }
      const body = await res.text();
      const hits = b.parse(body, n);
      if (hits.length) return { hits, backend: b.id, notes };
      notes.push(`${b.id}: no results parsed${/anomaly|captcha|unusual traffic/i.test(body) ? " (bot challenge page)" : ""}`);
    } catch (e) {
      notes.push(`${b.id}: ${String((e && e.message) || e).slice(0, 90)}`);
    }
  }
  return { hits: [], backend: null, notes };
}

function htmlToText(html) {
  let s = String(html || "");
  s = s.replace(/<script[\s\S]*?<\/script>/gi, " ");
  s = s.replace(/<style[\s\S]*?<\/style>/gi, " ");
  s = s.replace(/<noscript[\s\S]*?<\/noscript>/gi, " ");
  s = s.replace(/<!--[\s\S]*?-->/g, " ");
  s = s.replace(/<br\s*\/?>/gi, "\n");
  s = s.replace(/<\/(p|div|h[1-6]|li|tr|section|article|header|footer|blockquote|pre|ul|ol|table)>/gi, "\n");
  s = s.replace(/<(p|div|h[1-6]|li|tr|section|article|header|footer|blockquote|pre|ul|ol|table)\b[^>]*>/gi, "\n");
  s = s.replace(/<[^>]+>/g, " ");
  s = decodeEntities(s);
  s = s.replace(/[ \t]+\n/g, "\n").replace(/\n{3,}/g, "\n\n").replace(/[ \t]{2,}/g, " ").trim();
  return s;
}

// A JS-only shell ("enable JavaScript", a few hundred chars) is not a page we
// can read; the reader proxy renders it server-side and returns Markdown.
function looksLikeShell(text) {
  const t = String(text || "");
  if (t.length < 400) return true;
  return /enable javascript|javascript is (required|disabled)|checking your browser|just a moment|cf-browser-verification/i.test(t.slice(0, 600));
}
async function readerFallback(url, maxChars) {
  const res = await fetchWithTimeout("https://r.jina.ai/" + url, { headers: webHeaders() }, WEB_FETCH_TIMEOUT);
  if (!res.ok) throw new Error("reader HTTP " + res.status);
  let text = await res.text();
  if (!text || text.length < 40) throw new Error("reader returned nothing");
  const orig = text.length;
  if (orig > maxChars) text = text.slice(0, maxChars) + `\n\n…[truncated ${orig - maxChars} chars]`;
  return text;
}


// ── Blender (one-shot TCP 9876 via AgentScript) ─────────────────────────
// Native plazcode-agent.exe rejects add_server/uvx. Chrome cannot open raw TCP.
// Connect is a short PowerShell/Python probe of the blender-mcp addon the
// user already started. Tool calls write a JSON request, run blender_once,
// then read the JSON response. No daemon, so the agent console is not
// flooded with failed `start /B py` / shim-restart loops.
function isBlenderToolName(name) {
  const bare = String(name || "").split("/").pop().split(".").pop();
  return BLENDER_TOOL_NAMES.has(bare) || /^blender_/.test(bare);
}
const BLENDER_KEY = "rs-blender-on";
try {
  chrome.storage?.local.get(BLENDER_KEY, (o) => {
    if (o && o[BLENDER_KEY]) blenderAddon = true;
  });
} catch {}
function setBlender(on, err) {
  const was = blenderAddon;
  blenderAddon = !!on;
  blenderError = on ? "" : (err || blenderError);
  try { chrome.storage.local.set({ [BLENDER_KEY]: !!on }); } catch {}
  if (was !== blenderAddon) broadcastStatus();
}

async function sendLocalEngine(obj, timeout = 25000) {
  try { await ensurePairing(); } catch (error) { return { ok: false, error: error.message }; }
  if (engine === "local" && connected && ws && ws.readyState === WebSocket.OPEN) {
    return send(obj, timeout);
  }
  return await new Promise((resolve) => {
    let sock;
    try { sock = new WebSocket(`ws://127.0.0.1:${PORT_LOCAL}`, pairingProtocols()); }
    catch (e) { resolve({ ok: false, error: "plazcode-agent.exe is not running" }); return; }
    const id = 800000 + Math.floor(Math.random() * 99999);
    let settled = false;
    const done = (v) => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      try { sock.close(); } catch {}
      resolve(v);
    };
    const timer = setTimeout(() => done({ ok: false, error: "plazcode-agent.exe did not answer — is it running?" }), timeout);
    sock.onerror = () => done({ ok: false, error: "plazcode-agent.exe is not running" });
    sock.onopen = () => {
      try { sock.send(JSON.stringify({ ...obj, id })); }
      catch (e) { done({ ok: false, error: String(e) }); }
    };
    sock.onmessage = (ev) => {
      let msg;
      try { msg = JSON.parse(ev.data); } catch { return; }
      if (msg.type === "connected") {
        if (typeof msg.workspace_root === "string" && msg.workspace_root) localRoot = msg.workspace_root;
        return;
      }
      if (msg.type === "tool_result" && (msg.id == null || msg.id === id)) {
        done(msg.ok ? { ok: true, text: msg.text } : { ok: false, error: msg.error || "tool failed" });
        return;
      }
      if (msg.type === "error" && (msg.id == null || msg.id === id)) {
        done({ ok: false, error: msg.error || "error" });
      }
    };
  });
}

async function extText(name) {
  const r = await fetch(chrome.runtime.getURL(name));
  if (!r.ok) throw new Error("extension file missing: " + name);
  return await r.text();
}

async function localWrite(path, content) {
  const r = await sendLocalEngine({
    type: "call_tool", name: "write_file",
    arguments: { path, content },
  }, 20000);
  if (!r || !r.ok) throw new Error((r && r.error) || ("could not write " + path));
  return r.text || "";
}

async function localRead(path, offset) {
  const r = await sendLocalEngine({
    type: "call_tool", name: "read_file",
    arguments: { path, offset: offset || 1, limit: 4000 },
  }, 20000);
  if (!r || !r.ok) throw new Error((r && r.error) || ("could not read " + path));
  const lines = String(r.text || "").split("\n");
  const body = [];
  let more = false;
  let next = offset || 1;
  for (const ln of lines) {
    const cont = ln.match(/\.\.\. lines (\d+)/);
    if (cont) { more = true; next = Number(cont[1]); continue; }
    const m = ln.match(/^\s*\d+\s+\|\s(.*)$/);
    if (m) body.push(m[1]);
  }
  return { text: body.join("\n"), more, next, count: body.length };
}
async function localReadAll(path) {
  let offset = 1, chunks = [];
  for (let i = 0; i < 20; i++) {
    const part = await localRead(path, offset);
    if (part.text) chunks.push(part.text);
    if (!part.more || !part.count) break;
    offset = part.next || (offset + part.count);
  }
  return chunks.join("\n");
}

// Read ANY workspace file as base64 (images/binaries included) through the
// native AgentScript engine. This is the ONLY way browser-side code can get at
// bytes on disk, so it backs every "attach this file / screenshot" feature.
async function localReadBase64(path) {
  const r = await sendLocalEngine({ type: "call_tool", name: "read_file_base64", arguments: { path } }, 30000);
  if (!r || !r.ok) throw new Error((r && r.error) || ("could not read " + path));
  let parsed = null;
  try { parsed = JSON.parse(String(r.text || "")); } catch {}
  if (!parsed || !parsed.data) throw new Error("the bridge returned no file data for " + path);
  return parsed;
}

async function localRun(command, timeoutSeconds = 12) {
  return sendLocalEngine({
    type: "call_tool", name: "run_command",
    arguments: { command, timeout_seconds: timeoutSeconds },
  }, (timeoutSeconds + 8) * 1000);
}

function probeCommands(win) {
  if (win) {
    return [
      "powershell -NoProfile -Command try{$c=New-Object Net.Sockets.TcpClient;$c.ReceiveTimeout=2500;$c.Connect('127.0.0.1',9876);$c.Close();Write-Output BLENDER_UP}catch{Write-Output BLENDER_DOWN}",
    ];
  }
  return [
    "python3 -c \"import socket;s=socket.create_connection(('127.0.0.1',9876),2);s.close();print('BLENDER_UP')\"",
    "python -c \"import socket;s=socket.create_connection(('127.0.0.1',9876),2);s.close();print('BLENDER_UP')\"",
    "(echo >/dev/tcp/127.0.0.1/9876) >/dev/null 2>&1 && echo BLENDER_UP || echo BLENDER_DOWN",
  ];
}

async function probeBlenderTcp() {
  let plat = { os: "win" };
  try { plat = await chrome.runtime.getPlatformInfo(); } catch {}
  const win = plat.os === "win";
  let last = "";
  for (const cmd of probeCommands(win)) {
    const r = await localRun(cmd, 8);
    const text = String((r && (r.text || r.error)) || "");
    last = text;
    if (/BLENDER_UP/.test(text)) return { ok: true };
    if (r && r.ok === false && /not running|not connected|timeout/i.test(text)) {
      return { ok: false, error: "plazcode-agent.exe is not running — start it, then Connect Blender again." };
    }
  }
  const down = /BLENDER_DOWN/.test(last);
  const err = down
    ? "Blender addon is not on port 9876. In Blender: press N → MCP for Blender → Start MCP Server."
    : (last && last.slice(0, 220)) || "Could not reach Blender. Run plazcode-agent.exe, then Start MCP Server in Blender.";
  return { ok: false, error: err };
}

async function connectBlender() {
  const p = await probeBlenderTcp();
  if (!p.ok) {
    setBlender(false, p.error);
    broadcastStatus();
    return { ok: false, blender: false, error: p.error };
  }
  setBlender(true, "");
  try {
    const ping = await blenderCall("get_scene_info", {}, 20000);
    if (ping && ping.ok === false && /not listening|closed|refused|10061|Connection refused/i.test(String(ping.error || ""))) {
      setBlender(false, ping.error);
      broadcastStatus();
      return { ok: false, blender: false, error: ping.error };
    }
  } catch {}
  broadcastStatus();
  return { ok: true, blender: true };
}

async function agentWorkspaceRoot() {
  if (localRoot) return localRoot;
  const r = await sendLocalEngine({ type: "call_tool", name: "workspace_info", arguments: {} }, 12000);
  const t = String((r && r.text) || "");
  const m = t.match(/Workspace root:\s*(.+)/);
  if (m) { localRoot = m[1].trim(); return localRoot; }
  return "";
}

function pyLiteral(v) {
  if (v === null || v === undefined) return "None";
  if (typeof v === "boolean") return v ? "True" : "False";
  if (typeof v === "number") return Number.isFinite(v) ? String(v) : "0";
  if (typeof v === "string") return JSON.stringify(v);
  if (Array.isArray(v)) return "[" + v.map(pyLiteral).join(", ") + "]";
  const parts = [];
  for (const [k, val] of Object.entries(v)) parts.push(JSON.stringify(k) + ": " + pyLiteral(val));
  return "{" + parts.join(", ") + "}";
}

const BLENDER_CMD = {
  blender_export_fbx: "export_fbx", export_blender_fbx: "export_fbx",
  blender_import_fbx: "import_fbx", import_blender_fbx: "import_fbx",
  blender_export_obj: "export_obj", blender_import_obj: "import_obj",
  blender_mesh_dump: "dump", blender_send_to_studio: "dump",
  blender_group: "group", blender_ungroup: "ungroup",
  blender_parent: "parent", blender_unparent: "unparent", blender_join: "join",
  blender_move_to_collection: "move_to_collection",
  blender_list_collections: "list_collections", blender_list_objects: "list_objects",
  blender_delete: "delete", blender_duplicate: "duplicate", blender_rename: "rename",
  blender_select: "select", blender_transform: "transform",
  blender_apply_transforms: "apply_transforms", blender_set_origin: "set_origin",
  blender_shade_smooth: "shade_smooth", blender_set_material: "set_material",
  // ── Material toolkit (node-based; version-safe across Blender 3.x/4.x) ──
  blender_material_create: "material_create", blender_material_new: "material_create",
  blender_make_material: "material_create", blender_material_preset: "material_preset",
  blender_material_apply_preset: "material_preset", blender_material_set: "material_set",
  blender_material_edit: "material_set", blender_material_assign: "material_assign",
  blender_material_apply: "material_assign", blender_material_list: "material_list",
  blender_materials: "material_list", blender_material_inspect: "material_inspect",
  blender_material_info: "material_inspect", blender_material_remove: "material_remove",
  blender_material_delete: "material_remove", blender_material_noise: "material_noise",
  blender_material_texture: "material_noise", blender_material_image: "material_image",
  blender_material_texture_image: "material_image", blender_material_pbr: "material_pbr",
  blender_material_maps: "material_pbr",
  blender_add_modifier: "add_modifier", blender_boolean: "boolean",
  blender_add_cube: "add_cube", blender_add_sphere: "add_sphere",
  blender_add_cylinder: "add_cylinder", blender_add_cone: "add_cone",
  blender_add_plane: "add_plane", blender_add_torus: "add_torus",
  blender_add_monkey: "add_monkey", blender_add_empty: "add_empty",
  blender_add_camera: "add_camera", blender_add_light: "add_light",
  blender_add_ico_sphere: "add_ico_sphere", blender_add_grid: "add_grid",
  blender_add_circle: "add_circle", blender_add_text: "add_text",
  blender_clear_scene: "clear_scene",
  blender_select_all: "select_all", blender_deselect: "deselect",
  blender_invert_selection: "invert_selection", blender_select_children: "select_children",
  blender_get_selection: "get_selection",
  blender_translate: "translate", blender_rotate: "rotate_deg", blender_rotate_deg: "rotate_deg",
  blender_set_dimensions: "set_dimensions",
  blender_origin_to_bottom: "origin_to_bottom", blender_drop_to_ground: "drop_to_ground",
  blender_center: "center", blender_snap_to_grid: "snap_to_grid",
  blender_shade_flat: "shade_flat",
  blender_apply_modifiers: "apply_modifiers", blender_remove_modifier: "remove_modifier",
  blender_triangulate: "triangulate", blender_decimate: "decimate",
  blender_merge: "merge", blender_recalc_normals: "recalc_normals",
  blender_flip_normals: "flip_normals", blender_separate: "separate_loose",
  blender_subdivide: "subdivide", blender_uv_unwrap: "uv_unwrap",
  blender_array: "array", blender_mirror: "mirror",
  blender_hide: "hide", blender_unhide: "unhide", blender_unhide_all: "unhide_all",
  blender_hide_unselected: "hide_unselected",
  blender_undo: "undo", blender_redo: "redo",
  blender_frame_selected: "frame_selected", blender_stats: "stats",
  blender_save: "save_blend", blender_look_at: "look_at",
  blender_convert_to_mesh: "convert_to_mesh",
  blender_align_camera: "align_camera_axis", blender_align_camera_axis: "align_camera_axis",
  blender_view_axis: "view_axis", blender_camera_to_view: "camera_to_view",
  blender_set_camera_lens: "set_camera_lens",
  blender_scale: "scale", blender_bevel: "bevel", blender_solidify: "solidify",
  blender_extrude: "extrude", blender_add_curve: "add_curve", blender_add_armature: "add_armature",
  blender_keyframe: "keyframe_insert", blender_keyframe_insert: "keyframe_insert",
  blender_set_frame: "set_frame", blender_set_active_camera: "set_active_camera",
  blender_track_to: "track_to", blender_cursor_to_selected: "cursor_to_selected",
  blender_randomize: "randomize_transform", blender_randomize_transform: "randomize_transform",
  blender_hide_render: "hide_render", blender_subdivision: "subdivision",
  blender_subsurf: "subdivision", blender_origin_to_geometry: "origin_to_geometry",
};

async function blenderOpsCode(cmd, args) {
  let py = await extText("blender_ops.py");
  const status = "plazcode_status.json";
  const mesh = "plazcode_mesh.json";
  py = py.split("__PLAZCODE_CMD__").join(String(cmd || ""));
  py = py.split("__PLAZCODE_ARGS__").join(JSON.stringify(args || {}));
  py = py.split("__PLAZCODE_OUT__").join(JSON.stringify(status || "plazcode_status.json"));
  py = py.split("__PLAZCODE_MESH__").join(JSON.stringify(mesh || "plazcode_mesh.json"));
  return { py, status, mesh };
}

function wrapBlenderUserCode(code) {
  const src = String(code || "");
  if (!src.trim()) return src;
  if (src.indexOf("_plazcode_items") >= 0 && src.indexOf("_plazcode_src =") >= 0) return src;
  return [
    "import bpy, re as _plazcode_re",
    "_plazcode_src = " + JSON.stringify(src),
    "try:",
    "    _plazcode_items = set(getattr(it, 'identifier', str(it)) for it in bpy.context.scene.render.bl_rna.properties['engine'].enum_items)",
    "except Exception:",
    "    _plazcode_items = set()",
    "if 'BLENDER_EEVEE_NEXT' not in _plazcode_items and 'BLENDER_EEVEE' in _plazcode_items:",
    "    _plazcode_src = _plazcode_src.replace('BLENDER_EEVEE_NEXT', 'BLENDER_EEVEE')",
    "elif 'BLENDER_EEVEE' not in _plazcode_items and 'BLENDER_EEVEE_NEXT' in _plazcode_items:",
    "    _plazcode_src = _plazcode_re.sub(r'BLENDER_EEVEE(?!_NEXT)', 'BLENDER_EEVEE_NEXT', _plazcode_src)",
    "if not hasattr(bpy.context.scene, 'eevee_next') and hasattr(bpy.context.scene, 'eevee'):",
    "    _plazcode_src = _plazcode_src.replace('.eevee_next', '.eevee')",
    "exec(compile(_plazcode_src, '<or_blender>', 'exec'))",
  ].join("\n");
}

async function blenderPayload(name, args) {
  const bare = String(name || "").split("/").pop().split(".").pop();
  const a = args || {};
  if (bare === "get_scene_info" || bare === "blender_get_scene_info") return { type: "get_scene_info", params: {} };
  if (bare === "get_object_info" || bare === "blender_get_object_info") return { type: "get_object_info", params: { name: a.name || a.object_name || "" } };
  if (bare === "execute_blender_code" || bare === "execute_code" || bare === "blender_execute_code") return { type: "execute_code", params: { code: wrapBlenderUserCode(a.code || "") } };
  if (bare === "get_viewport_screenshot" || bare === "blender_screenshot") {
    let shot = "plazcode_blender_shot.png";
    const root = await agentWorkspaceRoot();
    if (root) shot = root.replace(/[\\/]+$/, "") + "/plazcode_blender_shot.png";
    // _orShot: the exact path we asked Blender to write, so blenderCall can read
    // the pixels back (see the screenshot branch there) without guessing.
    return { type: "get_viewport_screenshot", params: { max_size: Number(a.max_size) || 1000, filepath: shot, format: "png" }, _orShot: shot };
  }
  const mapped = BLENDER_CMD[bare];
  if (mapped) {
    const packed = await blenderOpsCode(mapped, a);
    return { type: "execute_code", params: { code: packed.py }, _orStatus: packed.status, _orMesh: packed.mesh };
  }
  const params = Object.assign({}, a);
  delete params.user_prompt;
  return { type: bare, params };
}

async function ensureBlenderScripts() {
  if (blenderScriptsReady) return;
  const py = await extText("blender_once.py");
  const ps = await extText("blender_once.ps1");
  await localWrite("blender_once.py", py);
  await localWrite("blender_once.ps1", ps);
  blenderScriptsReady = true;
}

let blenderCallLock = Promise.resolve();
async function blenderCall(name, args, timeout) {
  if (!blenderAddon) {
    return { ok: false, error: "Blender is not connected. Click Connect Blender (Blender: N → MCP for Blender → Start MCP Server)." };
  }
  const run = async () => {
    await ensureBlenderScripts();
    const payload = await blenderPayload(name, args);
    const statusPath = payload._orStatus || "";
    const meshPath = payload._orMesh || "";
    const wire = { type: payload.type, params: payload.params };
    await localWrite("plazcode_blender_in.json", JSON.stringify(wire));
    let plat = { os: "win" };
    try { plat = await chrome.runtime.getPlatformInfo(); } catch {}
    const win = plat.os === "win";
    const secs = Math.max(20, Math.min(180, Math.round((timeout || 120000) / 1000)));
    const cmds = win ? [
      "powershell -NoProfile -ExecutionPolicy Bypass -File blender_once.ps1 plazcode_blender_in.json plazcode_blender_out.json",
      "py -3 blender_once.py plazcode_blender_in.json plazcode_blender_out.json",
      "python blender_once.py plazcode_blender_in.json plazcode_blender_out.json",
    ] : [
      "python3 blender_once.py plazcode_blender_in.json plazcode_blender_out.json",
      "python blender_once.py plazcode_blender_in.json plazcode_blender_out.json",
    ];
    let last = "";
    let okRun = false;
    for (const cmd of cmds) {
      const r = await localRun(cmd, secs);
      last = String((r && (r.text || r.error)) || "");
      if (/PLAZCODE_BLENDER_OK/.test(last)) { okRun = true; break; }
      // Blender refused / socket error — do not try py/python after PowerShell already ran.
      if (/PLAZCODE_BLENDER_ERR/.test(last)) break;
      // Missing interpreter only: try the next runner. Anything else is a real error.
      if (!/not recognized|cannot find|No such file|not found|is not recognized/i.test(last)) break;
    }
    let raw = "";
    try { raw = (await localReadAll("plazcode_blender_out.json")).replace(/^\uFEFF/, "").trim(); } catch (e) {
      if (!okRun) return { ok: false, error: last.slice(0, 400) || String(e.message || e) };
    }
    let data;
    try { data = JSON.parse(raw); } catch {
      return { ok: false, error: raw ? raw.slice(0, 400) : (last.slice(0, 400) || "empty Blender response") };
    }
    if (data && data.status === "error") {
      const msg = data.message || "Blender addon error";
      if (/not listening|closed|actively refused|10061|Connection refused/i.test(msg)) {
        setBlender(false, "Blender addon dropped. Start MCP Server in Blender, then Connect Blender again.");
      }
      return { ok: false, error: msg };
    }
    let result = (data && Object.prototype.hasOwnProperty.call(data, "result")) ? data.result : data;
    const rawText = typeof result === "string" ? result : JSON.stringify(result);
    const marker = String(rawText).indexOf("PLAZCODE_MESH_JSON:");
    if (marker >= 0) {
      try { result = JSON.parse(String(rawText).slice(marker + 13)); } catch {}
    }
    if (result && result.ok === false) {
      return { ok: false, error: result.error || "Blender FBX failed" };
    }
    if (statusPath) {
      try {
        const st = (await localReadAll(statusPath)).replace(/^\uFEFF/, "").trim();
        if (st) {
          try { result = JSON.parse(st); } catch {}
        }
      } catch {}
    }
    if (result && result.ok === false) {
      return { ok: false, error: result.error || "Blender command failed" };
    }
    let meshes = result && result.meshes;
    const mf = (result && result.mesh_file) || meshPath || "plazcode_mesh.json";
    if ((!meshes || !meshes.length) && mf) {
      for (const cand of [mf, "plazcode_mesh.json"]) {
        try {
          const rawM = (await localReadAll(cand)).replace(/^\uFEFF/, "").trim();
          if (!rawM) continue;
          const parsed = JSON.parse(rawM);
          meshes = parsed.meshes || (parsed.result && parsed.result.meshes);
          if (meshes && meshes.length) break;
        } catch {}
      }
    }
    if (meshes && meshes.length && result && typeof result === "object") result.meshes = meshes;
    // ── Screenshot → real image bytes ──────────────────────────────────────
    // The blender-mcp addon WRITES the viewport capture to a PNG path and
    // answers with that path as text. A Chrome extension cannot read a local
    // path, so this used to hand back images:[] and plazcode_screenshot silently fell
    // through to a tab capture (the AI got a picture of its own chat window).
    // The path IS inside the AgentScript workspace, so read it back as base64
    // through the bridge and return it as a real attachment.
    let images = [];
    const shotPath = payload._orShot ||
      (result && typeof result === "object" && (result.filepath || result.file_path || result.path)) ||
      (payload.type === "get_viewport_screenshot" ? "plazcode_blender_shot.png" : "");
    if (shotPath && payload.type === "get_viewport_screenshot") {
      try {
        const parsed = await localReadBase64(shotPath);
        images = [{ mimeType: parsed.mimeType || "image/png", data: parsed.data }];
        if (result && typeof result === "object") result.bytes = parsed.bytes;
      } catch (e) {
        // Keep the path in the text so the model/user can still open the file;
        // report the reason rather than pretending a capture happened.
        result = typeof result === "object" && result
          ? Object.assign({}, result, { image_error: String((e && e.message) || e).slice(0, 200) })
          : result;
      }
    }
    let textOut = typeof result === "string" ? result : JSON.stringify(result, null, 2);
    if (payload.type === "get_viewport_screenshot" && !images.length) {
      textOut += "\n\n[PlazCode: the viewport image could not be read back from disk" +
        (shotPath ? ` (${shotPath})` : "") + " — the capture file may be missing or unreadable.]";
    }
    return { ok: true, text: textOut, images, meshFile: mf, filepath: result && result.filepath, meshes: meshes || undefined };
  };
  const prev = blenderCallLock;
  let release;
  blenderCallLock = new Promise((res) => { release = res; });
  await prev.catch(() => {});
  try { return await run(); }
  finally { release(); }
}

async function robloxCsrf() {
  try {
    const r = await fetch("https://auth.roblox.com/v2/logout", { method: "POST", credentials: "include" });
    return r.headers.get("x-csrf-token") || r.headers.get("X-CSRF-TOKEN") || "";
  } catch {
    return "";
  }
}
async function robloxAuthedFetch(url, opts) {
  opts = opts || {};
  const method = opts.method || "GET";
  const headers = Object.assign({}, method !== "GET" ? { "Content-Type": "application/json" } : {}, opts.headers || {});
  const go = async (token) => {
    const h = Object.assign({}, headers);
    if (token) h["X-CSRF-TOKEN"] = token;
    const r = await fetch(url, { method, credentials: "include", headers: h, body: opts.body });
    const text = await r.text();
    const csrf = r.headers.get("x-csrf-token") || r.headers.get("X-CSRF-TOKEN") || "";
    return { r, text, csrf };
  };
  let token = await robloxCsrf();
  let res = await go(token);
  if ((res.r.status === 403 || res.r.status === 401) && res.csrf && res.csrf !== token) {
    res = await go(res.csrf);
  }
  let data = null;
  try { data = JSON.parse(res.text); } catch {}
  return { ok: res.r.ok, status: res.r.status, text: res.text, data };
}
async function robloxResolveUniverse(msg) {
  let universeId = Number(msg.universeId || msg.universe_id || msg.gameId || 0) || 0;
  const placeId = Number(msg.placeId || msg.place_id || 0) || 0;
  if (universeId > 0) return { ok: true, universeId, placeId };
  if (placeId > 0) {
    const res = await robloxAuthedFetch("https://apis.roblox.com/universes/v1/places/" + placeId + "/universe", { method: "GET" });
    const id = Number(res.data && (res.data.universeId || res.data.id) || 0) || 0;
    if (id > 0) return { ok: true, universeId: id, placeId };
  }
  const listed = await robloxAuthedFetch("https://develop.roblox.com/v1/user/universes?limit=50&sortOrder=Desc", { method: "GET" });
  const rows = (listed.data && listed.data.data) || [];
  if (placeId > 0) {
    const hit = rows.find((u) => Number(u.rootPlaceId) === placeId || Number(u.id) === placeId);
    if (hit) return { ok: true, universeId: Number(hit.id), placeId, name: hit.name };
  }
  if (rows.length === 1) return { ok: true, universeId: Number(rows[0].id), placeId: Number(rows[0].rootPlaceId) || placeId, name: rows[0].name };
  if (rows.length > 1) {
    const top = rows[0];
    return {
      ok: true,
      universeId: Number(top.id),
      placeId: Number(top.rootPlaceId) || placeId,
      name: top.name,
      candidates: rows.slice(0, 8).map((u) => ({ id: u.id, name: u.name, rootPlaceId: u.rootPlaceId })),
    };
  }
  const who = await robloxAuthedFetch("https://users.roblox.com/v1/users/authenticated", { method: "GET" });
  if (!who.ok) return { ok: false, error: "Could not reach the game. Sign into roblox.com in this Chrome profile, publish the place in Studio, then retry." };
  return { ok: false, error: "Could not reach a universe for this place (GameId/PlaceId empty). Publish the place (File > Publish to Roblox) so it has a Universe ID." };
}
async function robloxCreateDevProduct(msg) {
  const resolved = await robloxResolveUniverse(msg);
  if (!resolved.ok) return resolved;
  const universeId = resolved.universeId;
  const name = String(msg.name || "").trim();
  const description = String(msg.description || name).trim();
  const priceInRobux = Math.floor(Number(msg.priceInRobux || msg.price || 0));
  if (!name) return { ok: false, error: "name required" };
  if (!priceInRobux || priceInRobux < 1) return { ok: false, error: "priceInRobux must be >= 1" };
  const qUrl = "https://apis.roblox.com/developer-products/v1/universes/" + universeId +
    "/developerproducts?name=" + encodeURIComponent(name) +
    "&description=" + encodeURIComponent(description) +
    "&priceInRobux=" + encodeURIComponent(String(priceInRobux));
  let res = await robloxAuthedFetch(qUrl, { method: "POST" });
  if (!res.ok && (res.status === 400 || res.status === 404 || res.status === 415)) {
    res = await robloxAuthedFetch("https://apis.roblox.com/developer-products/v1/universes/" + universeId + "/developerproducts", {
      method: "POST",
      body: JSON.stringify({ name: name, description: description, priceInRobux: priceInRobux }),
    });
  }
  if (!res.ok) {
    let err = res.text.slice(0, 280) || ("HTTP " + res.status);
    try {
      const d = res.data;
      if (d) err = d.message || d.error || (d.errors && d.errors[0] && d.errors[0].message) || err;
    } catch {}
    if (res.status === 401 || res.status === 403) {
      return { ok: false, error: "Not signed into Roblox in this Chrome profile. Open roblox.com, log in, then retry. (" + err + ")" };
    }
    return { ok: false, error: String(err) + " (universe " + universeId + (resolved.name ? " / " + resolved.name : "") + ")", status: res.status, universeId: universeId };
  }
  const product = res.data || {};
  return { ok: true, product: product, productId: product.id || product.productId, universeId: universeId, universeName: resolved.name || "", text: JSON.stringify(product) };
}
async function robloxListDevProducts(msg) {
  const resolved = await robloxResolveUniverse(msg);
  if (!resolved.ok) return resolved;
  const universeId = resolved.universeId;
  const url = "https://apis.roblox.com/developer-products/v1/universes/" + universeId + "/developerproducts?pageNumber=1&pageSize=50";
  const res = await robloxAuthedFetch(url, { method: "GET" });
  if (!res.ok) {
    const err = (res.data && (res.data.message || res.data.error)) || res.text.slice(0, 280) || ("HTTP " + res.status);
    if (res.status === 401 || res.status === 403) {
      return { ok: false, error: "Not signed into Roblox in this Chrome profile. Open roblox.com, log in, then retry. (" + err + ")" };
    }
    return { ok: false, error: String(err), status: res.status };
  }
  return { ok: true, products: res.data, text: typeof res.text === "string" ? res.text.slice(0, 4000) : JSON.stringify(res.data) };
}

// ── messages from content.js / popup.js ─────────────────────────────────
chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  (async () => {
    switch (msg.type) {
      case "rs-get-engine":
        sendResponse({ engine });
        break;
      case "rs-set-engine":
        engine = normalizeEngine(msg.engine);
        try { await chrome.storage.local.set({ [ENGINE_KEY]: engine }); } catch {}
        // fully isolate — wipe previous engine's cache so hallucination impossible
        try { ws?.close(); } catch {}
        connected = false;
        mcpAlive = false;
        toolsCache = [];
        serversCache = [];
        studioConnected = null;
        studioApp = null;
        studioProc = null;
        robloxEditorConnected = false;
        failAllPending(`engine switched to ${engine}`);
        reconnectDelay = RECONNECT_MIN;
        connect();
        broadcastStatus();
          // also push to all provider tabs so their bars / prompts flip instantly.
          // tabs.sendMessage returns a Promise in MV3 — orphaned content scripts
          // (tab not refreshed after reload) reject with "Receiving end does not
          // exist"; that's expected and harmless here, so swallow it.
          try {
            const tabs = await chrome.tabs.query({ url: PROVIDER_URLS });
            for (const t of tabs) chrome.tabs.sendMessage(t.id, { type: "rs-engine", engine }).catch(() => {});
          } catch {}
        sendResponse({ engine });
        break;
      case "rs-set-full": {
        // FULL PC ACCESS toggle for the AgentScript engine. The agent process
        // is the source of truth; mirror its answer into the status broadcast.
        const want = !!msg.enabled;
        try {
          const r = await bridgeFetch("http://127.0.0.1:3000/api/local-full", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ enabled: want }),
          });
          const j = await r.json().catch(() => ({}));
          if (!r.ok || typeof j.local_full !== "boolean") throw new Error("Agent did not confirm the permission change");
          localFull = j.local_full;
          try { chrome.storage.local.set({ "rs-local-full": localFull }); } catch {}
        } catch (error) {
          sendResponse({ ok: false, enabled: localFull, error: String(error.message || error) });
          break;
        }
        broadcastStatus();
        sendResponse({ ok: true, enabled: localFull });
        break;
      }
      case "rs-get-full":
        sendResponse({ enabled: localFull });
        break;
      case "status":
        if (!connected) connect(); // self-heal after a worker wake-up
        sendResponse(statusObj());
        break;
      case "list_tools": {
        // Prefer a live refresh; fall back to cache so the loop never stalls.
        // 10s, not 25s: a catalogue request only blocks this long when one of the
        // MCP servers is dead (typically Roblox in a degraded, Blender-only
        // session), and in that exact case we already hold a perfectly good cached
        // catalogue. Waiting the full 25s just froze the boot for no new data.
        const r = await send({ type: "list_tools" }, 10000);
        if (r.ok && Array.isArray(r.tools)) toolsCache = r.tools;
        const tools = mergeBlenderTools(r.ok ? toolsCache : toolsCache);
        const ok = r.ok || tools.length > 0;
        sendResponse({ ok, tools, error: r.ok ? undefined : r.error });
        break;
      }
      case "call_tool": {
        const timeout = (msg.timeout || 120000) + 10000;
        if (blenderAddon && isBlenderToolName(msg.name)) {
          sendResponse(await blenderCall(msg.name, msg.arguments, timeout));
          break;
        }
        const r = await send(
          { type: "call_tool", name: msg.name, arguments: msg.arguments, timeout: msg.timeout },
          timeout
        );
        sendResponse(r);
        break;
      }
      case "restart_mcp": {
        const r = await send({ type: "restart_mcp" }, 30000);
        if (r && r.ok) {
          const tools = await send({ type: "list_tools" }, 10000);
          if (tools && tools.ok && Array.isArray(tools.tools)) toolsCache = tools.tools;
          mcpAlive = true;
        }
        sendResponse(r);
        break;
      }
      case "local_read": {
        try {
          const text = await localReadAll(String(msg.path || ""));
          sendResponse({ ok: true, text });
        } catch (e) {
          sendResponse({ ok: false, error: String(e && e.message || e) });
        }
        break;
      }
      // Base64 read (any file: images, PDFs, binaries) — powers attach_feedback
      // ({"path": ...}), which puts a workspace file into the chat as an
      // attachment instead of pasting its text.
      case "local_read_base64": {
        try {
          const data = await localReadBase64(String(msg.path || ""));
          sendResponse({ ok: true, path: data.path, mimeType: data.mimeType, bytes: data.bytes, data: data.data });
        } catch (e) {
          sendResponse({ ok: false, error: String(e && e.message || e) });
        }
        break;
      }
      case "blender_connect": {
        sendResponse(await connectBlender());
        break;
      }
      case "blender_status": {
        sendResponse({ ok: blenderAddon, blender: blenderAddon, error: blenderError || undefined });
        break;
      }
      case "blender_disconnect": {
        setBlender(false, "");
        broadcastStatus();
        sendResponse({ ok: true, blender: false });
        break;
      }
      case "add_server": {
        // Native plazcode-agent.exe rejects custom MCP. Blender uses blender_connect.
        if (String(msg.server_id || "").toLowerCase() === "blender") {
          sendResponse(await connectBlender());
          break;
        }
        const r = await send({
          type: "add_server", server_id: msg.server_id,
          command: msg.command, args: msg.args, env: msg.env,
        }, 15000);
        sendResponse(r);
        break;
      }
      case "remove_server": {
        const r = await send({ type: "remove_server", server_id: msg.server_id }, 15000);
        sendResponse(r);
        break;
      }
      case "reconnect":
        reconnectDelay = RECONNECT_MIN;
        connect();
        sendResponse({ ok: true });
        break;
      // ── ZeroScript Rust pipe — CORS bypass via background (content script → background → 127.0.0.1) ──
      case "rs-push":
      case "push_payload": {
        // Content script payload from AI chat (Gemini/ChatGPT/Claude) → local bridge
        // Must go through background to bypass chat site CORS on http://127.0.0.1
        try {
          const target = RUST_ROBLOX_HTTP;
          const res = await bridgeFetch(`${target}/api/push`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(msg.payload || msg),
          });
          const j = await res.json().catch(() => ({}));
          sendResponse({ ok: res.ok, ...j });
        } catch (e) {
          // Fallback to legacy WS if Rust HTTP not reachable
          const r = await send({ type: "call_tool", name: msg.name || "push_payload", arguments: msg.arguments || msg.payload || {} }, 10000);
          sendResponse(r);
        }
        break;
      }
      case "rs-poll": {
        try {
          const target = RUST_ROBLOX_HTTP;
          const res = await bridgeFetch(`${target}/api/poll?client_id=${encodeURIComponent(msg.client_id || engine)}`);
          const j = await res.json().catch(() => ({}));
          sendResponse(j);
        } catch (e) {
          sendResponse({ ok: false, error: String(e && e.message || e) });
        }
        break;
      }
      case "web_fetch": {
        try {
          let url = String(msg.url || "").trim();
          const query = String(msg.query || "").trim();
          if (!url) {
            const q = String(msg.q || query).trim();
            if (/^https?:\/\//i.test(q)) url = q;
          }
          let searchNote = "";
          if (!url) {
            const q = query || String(msg.q || "").trim();
            if (!q) { sendResponse({ ok: false, error: "url or query is required" }); break; }
            const found = await webSearch(q, 3);
            if (!found.hits.length) {
              sendResponse({ ok: false, error: `no search results for: ${q} (tried ${found.notes.join("; ") || "all backends"})` });
              break;
            }
            url = found.hits[0].url;
            searchNote = `Searched "${q}" [${found.backend}]. Top result: ${url}\n` +
              found.hits.map((h, i) => (i + 1) + ". " + h.title + " — " + h.url).join("\n") + "\n\n";
          }
          if (!/^https?:\/\//i.test(url)) { sendResponse({ ok: false, error: "url must start with http:// or https://" }); break; }
          const maxChars = Math.max(500, Math.min(50000, Number(msg.max_chars) || 12000));
          let text = "";
          let directWasHtml = false;
          let status = 0;
          let ctype = "";
          let via = "direct";
          const notes = [];
          try {
            const res = await fetchWithTimeout(url, { headers: webHeaders({}, (() => { try { return new URL(url).origin + "/"; } catch { return undefined; } })()) }, WEB_FETCH_TIMEOUT);
            status = res.status;
            ctype = (res.headers.get("content-type") || "").toLowerCase();
            if (!res.ok) {
              notes.push(`direct HTTP ${res.status}`);
            } else {
              let raw = await res.text();
              const looksHtml = /html|xml/.test(ctype) || /^\s*</.test(raw);
              directWasHtml = looksHtml;
              text = looksHtml ? htmlToText(raw) : raw.trim();
            }
          } catch (e) {
            notes.push("direct: " + String((e && e.message) || e).slice(0, 90));
          }
          // Reader proxy when the direct fetch failed, was blocked, or returned
          // a JavaScript shell we cannot read.
          // Short pages are only suspicious when they were HTML: a 200-char
          // plain-text/JSON answer is a complete document, and re-reading it
          // through a proxy would be wasted time.
          const wasShell = !text || (directWasHtml && looksLikeShell(text));
          if (wasShell) {
            try {
              const viaReader = await readerFallback(url, maxChars);
              if (viaReader) { text = viaReader; via = "reader"; }
            } catch (e) {
              notes.push("reader: " + String((e && e.message) || e).slice(0, 90));
            }
          }
          if (!text) {
            sendResponse({ ok: false, error: `fetch failed for ${url}${notes.length ? " (" + notes.join("; ") + ")" : ""}` });
            break;
          }
          const origLen = text.length;
          const truncated = origLen > maxChars;
          if (truncated) text = text.slice(0, maxChars) + `\n\n…[truncated ${origLen - maxChars} chars]`;
          const suffix = via === "reader"
            ? `\n\n[PlazCode: the page served no readable text directly (${notes.join("; ") || "blocked"}), so it was read through a rendering proxy — layout/menus may be missing.]`
            : (wasShell
              ? `\n\n[PlazCode: this page returned almost no readable text${notes.length ? " (" + notes.join("; ") + ")" : ""} — it is served by JavaScript or blocks non-browser readers, so the text above is all there is. Use web_search for a text source instead of relying on this page.]`
              : "");
          sendResponse({ ok: true, text: searchNote + text + suffix, truncated, status, url, content_type: ctype, via });
        } catch (e) { sendResponse({ ok: false, error: String(e && e.message || e) }); }
        break;
      }
      case "web_search": {
        try {
          const q = String(msg.query || msg.q || "").trim();
          if (!q) { sendResponse({ ok: false, error: "query is required" }); break; }
          const limit = Math.max(1, Math.min(8, Number(msg.limit) || 3));
          const found = await webSearch(q, limit);
          if (!found.hits.length) {
            sendResponse({ ok: false, error: `no results for '${q}' (tried ${found.notes.join("; ") || "all backends"})`, notes: found.notes });
            break;
          }
          const results = found.hits;
          const txt = results.map((r, i) => `${i + 1}. ${r.title}\n   ${r.url}`).join("\n");
          sendResponse({ ok: true, text: `Searched "${q}" [${found.backend}]\n${txt}`, results, query: q, backend: found.backend, notes: found.notes });
        } catch (e) { sendResponse({ ok: false, error: String(e && e.message || e) }); }
        break;
      }
      case "ollama_list_models": {
        try {
          const res = await fetch("http://127.0.0.1:11434/api/tags");
          if (!res.ok) { sendResponse({ ok: false, error: `Ollama not running (HTTP ${res.status}) — run 'ollama serve'` }); break; }
          const j = await res.json();
          sendResponse({ ok: true, models: j.models || [] });
        } catch (e) { sendResponse({ ok: false, error: `Ollama not reachable at 127.0.0.1:11434 — is 'ollama serve' running? ${String(e&&e.message||e)}` }); }
        break;
      }
      // One-click start: ask whichever bridge is connected to spawn `ollama serve`.
      case "ollama_ensure": {
        const ask = (type) => send({ type, timeoutMs: 12000 });
        let r = await ask("start_ollama");
        if (!r || r.error === "bridge not connected") {
          // Engine bridge down? try the other port by flipping engine briefly is
          // too invasive; instead just report so popup can hint to run robloxscript-agent.exe.
          sendResponse({ ok: false, up: false, error: "bridge offline - run plazcode-agent.exe first" });
          break;
        }
        sendResponse(r);
        break;
      }
      case "ollama_status": {
        const r = await send({ type: "ollama_status" }, 8000);
        if (!r || r.error === "bridge not connected") {
          sendResponse({ ok: false, up: false, error: "bridge offline" });
          break;
        }
        sendResponse(r);
        break;
      }
      case "ollama_chat": {
        try {
          let model = msg.model ? String(msg.model) : "";
          const messages = Array.isArray(msg.messages) ? msg.messages : [{role:"user", content:String(msg.prompt||"")}];
          // Validate the model against what is ACTUALLY installed before calling
          // /api/chat - a stale name (model deleted after being picked, or the
          // hardcoded default no longer pulled) otherwise surfaces as a raw 404
          // body. Return a structured error the page can react to (auto-recover).
          let available = [];
          try {
            const tr = await fetch("http://127.0.0.1:11434/api/tags");
            if (tr.ok) { const tj = await tr.json(); available = (tj.models || []).map(m => m.name); }
          } catch {}
          if (!available.length) {
            sendResponse({ ok:false, errKind:"no_server", error:"ERR: OLLAMA NOT RUNNING - nothing answered on 127.0.0.1:11434." });
            break;
          }
          if (!model || !available.includes(model)) {
            if (model) {
              sendResponse({
                ok: false, errKind: "model_not_found", available,
                error: `ERR: MODEL NOT FOUND - "${model}" is not installed anymore.`
              });
              break;
            }
            // No model given: fall back to a coder model if present, else first.
            const pref = available.find(n => /coder|code/i.test(n));
            model = pref || available[0];
          }
          const res = await fetch("http://127.0.0.1:11434/api/chat", {
            method: "POST",
            headers: { "Content-Type":"application/json" },
            body: JSON.stringify({ model, messages, stream: false })
          });
          if (!res.ok) {
            const t = await res.text().catch(()=> "");
            sendResponse({ ok: false, errKind:"http_"+res.status, model,
              error: `Ollama chat HTTP ${res.status}: ${t.slice(0,400)}` });
            break;
          }
          const j = await res.json();
          const text = (j.message && j.message.content) || j.response || "";
          sendResponse({ ok: true, text, model, raw: j });
        } catch (e) { sendResponse({ ok: false, error: `Ollama chat failed: ${String(e&&e.message||e)} - try OLLAMA_ORIGINS=* ollama serve` }); }
        break;
      }
      case "resolve_universe": {
        try { sendResponse(await robloxResolveUniverse(msg)); }
        catch (e) { sendResponse({ ok: false, error: String(e && e.message || e) }); }
        break;
      }
      case "create_dev_product": {
        try { sendResponse(await robloxCreateDevProduct(msg)); }
        catch (e) { sendResponse({ ok: false, error: String(e && e.message || e) }); }
        break;
      }
      case "list_dev_products": {
        try { sendResponse(await robloxListDevProducts(msg)); }
        catch (e) { sendResponse({ ok: false, error: String(e && e.message || e) }); }
        break;
      }
      case "capture_tab": {
        try {
          const windowId = (_sender.tab && _sender.tab.windowId) || undefined;
          const dataUrl = await new Promise((resolve, reject) => {
            try {
              chrome.tabs.captureVisibleTab(windowId, { format: "png" }, (url) => {
                if (chrome.runtime.lastError) reject(new Error(chrome.runtime.lastError.message));
                else resolve(url);
              });
            } catch (e) { reject(e); }
          });
          const m = String(dataUrl || "").match(/^data:(image\/[a-zA-Z0-9.+-]+);base64,(.+)$/);
          if (!m) {
            sendResponse({ ok: false, error: "tab capture returned no image" });
            break;
          }
          sendResponse({ ok: true, images: [{ mimeType: m[1], data: m[2] }] });
        } catch (e) {
          sendResponse({ ok: false, error: String(e && e.message || e) });
        }
        break;
      }
      case "tab_read": {
        try {
          const tab = await resolveTab(msg);
          if (!tab) { sendResponse({ ok: false, error: "no target tab (open a page, or pass url_contains)" }); break; }
          const [res] = await chrome.scripting.executeScript({
            target: { tabId: tab.id },
            func: () => {
              const isVisible = (el) => {
                const r = el.getBoundingClientRect();
                const s = getComputedStyle(el);
                return r.width > 0 && r.height > 0 && s.visibility !== "hidden" && s.display !== "none" && r.bottom > 0 && r.top < innerHeight;
              };
              const text = (document.body && document.body.innerText || "").replace(/\n{3,}/g, "\n\n").slice(0, 6000);
              const clickable = [];
              const els = document.querySelectorAll("a, button, input, [role=button], [onclick], summary, select, textarea");
              let i = 0;
              for (const el of els) {
                if (!isVisible(el)) continue;
                const label = (el.innerText || el.value || el.getAttribute("aria-label") || el.getAttribute("placeholder") || el.getAttribute("title") || el.name || "").trim().replace(/\s+/g, " ").slice(0, 80);
                clickable.push({ i, tag: el.tagName.toLowerCase(), type: el.type || "", label, id: el.id || "", cls: (el.className && String(el.className).slice(0, 60)) || "" });
                i++;
                if (i >= 120) break;
              }
              return { url: location.href, title: document.title, text, clickable };
            },
          });
          sendResponse({ ok: true, tab: { id: tab.id, url: tab.url, title: tab.title }, page: res.result });
        } catch (e) { sendResponse({ ok: false, error: String(e && e.message || e) }); }
        break;
      }
      case "tab_click": {
        try {
          const tab = await resolveTab(msg);
          if (!tab) { sendResponse({ ok: false, error: "no target tab" }); break; }
          const [res] = await chrome.scripting.executeScript({
            target: { tabId: tab.id },
            args: [String(msg.selector || ""), String(msg.text || "")],
            func: (selector, text) => {
              let el = null;
              if (selector) el = document.querySelector(selector);
              if (!el && text) {
                const t = text.toLowerCase();
                const cands = Array.from(document.querySelectorAll("a, button, input, [role=button], [onclick], summary, select, textarea, label"));
                el = cands.find((c) => ((c.innerText || c.value || c.getAttribute("aria-label") || c.getAttribute("placeholder") || "").toLowerCase().includes(t)));
              }
              if (!el) return { clicked: false, error: "element not found" };
              el.scrollIntoView({ block: "center" });
              el.focus && el.focus();
              el.click();
              return { clicked: true, tag: el.tagName.toLowerCase(), label: (el.innerText || el.value || "").trim().slice(0, 60) };
            },
          });
          sendResponse({ ok: true, result: res.result });
        } catch (e) { sendResponse({ ok: false, error: String(e && e.message || e) }); }
        break;
      }
      case "tab_type": {
        try {
          const tab = await resolveTab(msg);
          if (!tab) { sendResponse({ ok: false, error: "no target tab" }); break; }
          const [res] = await chrome.scripting.executeScript({
            target: { tabId: tab.id },
            args: [String(msg.selector || ""), String(msg.text || ""), !!msg.submit],
            func: (selector, text, submit) => {
              const el = selector ? document.querySelector(selector) : document.activeElement;
              if (!el) return { typed: false, error: "no field (pass selector)" };
              el.focus();
              if ("value" in el) {
                el.value = text;
                el.dispatchEvent(new Event("input", { bubbles: true }));
                el.dispatchEvent(new Event("change", { bubbles: true }));
              } else {
                el.textContent = text;
              }
              if (submit) {
                const k = new KeyboardEvent("keydown", { key: "Enter", code: "Enter", keyCode: 13, bubbles: true });
                el.dispatchEvent(k);
                if (el.form && el.form.requestSubmit) el.form.requestSubmit();
              }
              return { typed: true, tag: el.tagName.toLowerCase() };
            },
          });
          sendResponse({ ok: true, result: res.result });
        } catch (e) { sendResponse({ ok: false, error: String(e && e.message || e) }); }
        break;
      }
      case "tab_scroll": {
        try {
          const tab = await resolveTab(msg);
          if (!tab) { sendResponse({ ok: false, error: "no target tab" }); break; }
          const [res] = await chrome.scripting.executeScript({
            target: { tabId: tab.id },
            args: [Number(msg.amount) || 600],
            func: (amount) => { window.scrollBy({ top: amount, behavior: "smooth" }); return { scrolled: amount, y: Math.round(window.scrollY) }; },
          });
          sendResponse({ ok: true, result: res.result });
        } catch (e) { sendResponse({ ok: false, error: String(e && e.message || e) }); }
        break;
      }
      default:
        sendResponse({ ok: false, error: "unknown message" });
    }
  })();
  return true; // async sendResponse
});

// Pick the tab a tab_* tool should act on: explicit tabId > a tab whose URL
// contains url_contains > the active tab in any window that is NOT a chat
// provider (so "control my browser" doesn't click the chat itself).
async function resolveTab(msg) {
  try {
    if (msg && msg.tabId != null) {
      const t = await chrome.tabs.get(Number(msg.tabId));
      return t || null;
    }
    const all = await chrome.tabs.query({});
    if (msg && msg.url_contains) {
      const needle = String(msg.url_contains).toLowerCase();
      return all.find((t) => (t.url || "").toLowerCase().includes(needle)) || null;
    }
    const isProvider = (u) => PROVIDER_URLS.some((p) => {
      const rx = new RegExp("^" + p.replace(/[.+?^${}()|[\]\\]/g, "\\$&").replace(/\*/g, ".*"));
      return rx.test(u || "");
    });
    const candidates = all.filter((t) => t.url && !isProvider(t.url));
    const active = candidates.find((t) => t.active);
    return active || candidates[candidates.length - 1] || all.find((t) => t.active) || null;
  } catch (_e) { return null; }
}

// Proc poll — keeps RS availability gated on the live Studio process
refreshProcStatus();
setInterval(refreshProcStatus, 5000);

// Wake/keepalive hooks.
chrome.runtime.onStartup.addListener(connect);
chrome.runtime.onInstalled.addListener(connect);

connect();
